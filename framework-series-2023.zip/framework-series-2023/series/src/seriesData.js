// seriesData.js
const seriesData = [
    {
      nome: "Good Girls",
      generos: ["Crime", "Drama", "Comédia"],
      descricao: "Três donas de casa suburbanas entram no mundo do crime para melhorar suas vidas financeiras."
    },
    // ... Outras séries
  ];
  
  export default seriesData;
  