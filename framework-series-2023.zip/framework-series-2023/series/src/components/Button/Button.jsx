// src/components/Button.js
import React from 'react';

function Button({ text }) {
  return <button>{text}</button>;
}

export default Button;
